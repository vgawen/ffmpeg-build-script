.. cmake-module:: ../../Modules/CheckOBJCXXSourceRuns.cmake
