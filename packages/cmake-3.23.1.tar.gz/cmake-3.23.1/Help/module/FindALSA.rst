.. cmake-module:: ../../Modules/FindALSA.cmake
