Sord
====

Sord is a lightweight C library for storing RDF statements in memory.
For more information, see <http://drobilla.net/software/sord>.

 -- David Robillard <d@drobilla.net>

