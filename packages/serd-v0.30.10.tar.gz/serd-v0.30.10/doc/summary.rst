Serd is a lightweight C library for reading and writing RDF in Turtle_, NTriples_, NQuads_, and TriG_.

.. _Turtle: http://www.w3.org/TR/turtle/
.. _NTriples: http://www.w3.org/TR/n-triples/
.. _NQuads: http://www.w3.org/TR/n-quads/
.. _TriG: http://www.w3.org/TR/trig/
