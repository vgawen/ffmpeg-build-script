####
Serd
####

.. include:: summary.rst

.. toctree::

   overview
   api/serd
